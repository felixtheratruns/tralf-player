from filebrowser.tests.settings import SettingsTests
from filebrowser.tests.base import FileObjectPathTests, FileObjectVersionTests, FileObjectUnicodeTests
from filebrowser.tests.sites import *
