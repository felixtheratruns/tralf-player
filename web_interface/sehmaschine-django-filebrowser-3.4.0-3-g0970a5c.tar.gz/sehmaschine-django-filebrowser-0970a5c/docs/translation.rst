.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _translation:

Translation
===========

.. versionadded:: 3.3

Translation is done via `Transifex <https://www.transifex.net/projects/p/django-filebrowser/>`_.

Supported Languages
===================

see https://www.transifex.net/projects/p/django-filebrowser/resource/djangopo/
