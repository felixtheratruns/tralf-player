:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _changelog:

Changelog
=========

3.4.1 (not yet released)
^^^^^^^^^^^^^^^^^^^^^^^^

3.4.0 (15/11/2011)
^^^^^^^^^^^^^^^^^^

* Final release of 3.4, see :ref:`releasenotes`